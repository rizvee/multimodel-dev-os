# Quickstart

Get multimodel-dev-os into your project in under 2 minutes.

## Option A: One-Line Install

**macOS / Linux / WSL (bash):**
```bash
curl -fsSL https://raw.githubusercontent.com/rizvee/multimodel-dev-os/main/scripts/install.sh | bash
```

**Windows (PowerShell):**
```powershell
irm https://raw.githubusercontent.com/rizvee/multimodel-dev-os/main/scripts/install.ps1 | iex
```

## Option B: Manual Scaffolding

```bash
git clone https://github.com/rizvee/multimodel-dev-os.git /tmp/mmdos
cp /tmp/mmdos/AGENTS.md    your-project/
cp /tmp/mmdos/MEMORY.md    your-project/
cp /tmp/mmdos/TASKS.md     your-project/
cp /tmp/mmdos/RUNBOOK.md   your-project/
cp /tmp/mmdos/.gitattributes your-project/
cp -r /tmp/mmdos/.ai       your-project/
```

## Option C: Caveman Mode (Minimal Tokens)

```bash
curl -fsSL https://raw.githubusercontent.com/rizvee/multimodel-dev-os/main/scripts/install.sh | bash -s -- --caveman
```

## Option D: Node.js CLI Scaffolding (v0.2.0+)

For a direct, highly customized local setup using our zero-dependency CLI utility:
1. Clone this repository locally:
   ```bash
   git clone https://github.com/rizvee/multimodel-dev-os.git
   ```
2. Run the CLI to scaffold into your target project:
   ```bash
   node bin/multimodel-dev-os.js init --target /path/to/your-project --template nextjs-saas --adapter cursor
   ```

## Option E: npx Scaffolding (Planned v0.3.0+)

Once published to the public npm registry, you can initialize any project globally without local clones using:
```bash
# General setup
npx multimodel-dev-os init

# Target specific layouts and templates
npx multimodel-dev-os init --template nextjs-saas --adapter cursor
```

## After Install

1. **Edit `AGENTS.md`** — fill in your project name, stack, and build commands
2. **Edit `.ai/config.yaml`** — enable adapters for your tools
3. **Copy adapter files** to your project root:
   - Cursor: `cp adapters/cursor/.cursorrules .cursorrules`
   - Claude: `cp adapters/claude/CLAUDE.md CLAUDE.md`
   - VS Code: `cp -r adapters/vscode/.vscode/ .vscode/`
4. **Start coding** — your AI tools will read the shared config

## Verify

You can run our strict verification script to validate structural health:
```bash
# Via CLI
node bin/multimodel-dev-os.js verify --target /path/to/your-project

# Via verification shell script
bash scripts/verify.sh
```

## Next Steps

- [Architecture overview](architecture.md)
- [Adapter setup](adapters.md)
- [Multi-agent workflows](multimodel-workflow.md)
- [Caveman Mode](caveman-mode.md)
- [NPM Publishing Runbook](npm-publishing.md)
